# Customer Purchase Behavior Segmentation

Groups customers using RFM (Recency, Frequency, Monetary) features and K-Means clustering.

## Setup
pip install -r requirements.txt

## Run
python customer_segmentation.py                     # demo with generated sample data
python customer_segmentation.py --data sales.csv    # your data: customer_id, order_date, amount
python customer_segmentation.py --clusters 4        # force number of segments

## Output (./output)
- customer_segments.csv  - every customer with RFM values and segment
- segment_summary.csv    - size, spend and revenue share per segment
- choose_k.png, segments_scatter.png, segment_sizes.png
